const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;
const SECRET = process.env.JWT_SECRET || "change-this-secret-before-deployment";

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// -------------------- DATABASE --------------------
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/staffsync")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB connection error:", err.message));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  role: { type: String, enum: ["HR", "Manager", "Employee"], default: "Employee" },
  department: { type: String, default: "General" }
}, { timestamps: true });

const leaveSchema = new mongoose.Schema({
  employee: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  employeeName: String,
  email: String,
  type: { type: String, required: true },
  reason: { type: String, required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  status: { type: String, enum: ["Pending", "Approved", "Rejected"], default: "Pending" },
  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }
}, { timestamps: true });

const attendanceSchema = new mongoose.Schema({
  employee: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  employeeName: String,
  email: String,
  date: { type: String, required: true },
  checkIn: { type: Date, default: Date.now },
  status: { type: String, default: "Present" }
}, { timestamps: true });
attendanceSchema.index({ employee: 1, date: 1 }, { unique: true });

const announcementSchema = new mongoose.Schema({
  title: { type: String, required: true },
  message: { type: String, required: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

const trainingSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, default: "" },
  date: { type: Date, required: true },
  department: { type: String, default: "All Departments" },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Leave = mongoose.model("Leave", leaveSchema);
const Attendance = mongoose.model("Attendance", attendanceSchema);
const Announcement = mongoose.model("Announcement", announcementSchema);
const Training = mongoose.model("Training", trainingSchema);

// -------------------- AUTH MIDDLEWARE --------------------
function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Authentication required" });

  try {
    req.auth = jwt.verify(token, SECRET);
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
}

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.auth.role)) {
    return res.status(403).json({ message: "You do not have permission" });
  }
  next();
};

const publicUser = user => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  department: user.department
});

// -------------------- AUTH ROUTES --------------------
// Run once to create the first HR account. Disabled after first account exists.
app.post("/api/setup", async (req, res) => {
  try {
    if (await User.countDocuments() > 0) {
      return res.status(403).json({ message: "Initial setup is already completed" });
    }
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 8) {
      return res.status(400).json({ message: "Name, email and password (8+ characters) are required" });
    }
    const user = await User.create({
      name, email, password: await bcrypt.hash(password, 12), role: "HR"
    });
    res.status(201).json({ message: "First HR account created", user: publicUser(user) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").toLowerCase();
    const user = await User.findOne({ email }).select("+password");
    if (!user || !(await bcrypt.compare(req.body.password || "", user.password))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }
    const token = jwt.sign(
      { id: user._id.toString(), name: user.name, email: user.email, role: user.role },
      SECRET,
      { expiresIn: "1d" }
    );
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get("/api/me", authenticate, async (req, res) => {
  const user = await User.findById(req.auth.id);
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json({ user: publicUser(user) });
});

// -------------------- EMPLOYEE ROUTES --------------------
app.get("/api/employees", authenticate, authorize("HR", "Manager"), async (_req, res) => {
  const employees = await User.find().select("-password").sort({ name: 1 });
  res.json(employees.map(publicUser));
});

app.post("/api/employees", authenticate, authorize("HR"), async (req, res) => {
  try {
    const { name, email, password, role = "Employee", department = "General" } = req.body;
    if (!name || !email || !password || password.length < 8) {
      return res.status(400).json({ message: "Name, email and password (8+ characters) are required" });
    }
    if (!["Manager", "Employee"].includes(role)) {
      return res.status(400).json({ message: "HR can create Manager or Employee accounts" });
    }
    const user = await User.create({
      name, email, password: await bcrypt.hash(password, 12), role, department
    });
    res.status(201).json({ message: "Employee account created", user: publicUser(user) });
  } catch (err) {
    res.status(400).json({ message: err.code === 11000 ? "Email already exists" : err.message });
  }
});

// -------------------- LEAVE ROUTES --------------------
app.get("/api/leaves", authenticate, async (req, res) => {
  const filter = req.auth.role === "Employee" ? { employee: req.auth.id } : {};
  const leaves = await Leave.find(filter)
    .populate("employee", "name email department")
    .populate("reviewedBy", "name")
    .sort({ createdAt: -1 });
  res.json(leaves);
});

app.post("/api/leaves", authenticate, authorize("Employee"), async (req, res) => {
  try {
    const { type, reason, startDate, endDate } = req.body;
    if (!type || !reason || !startDate || !endDate || new Date(endDate) < new Date(startDate)) {
      return res.status(400).json({ message: "Provide valid leave details and dates" });
    }
    const leave = await Leave.create({
      employee: req.auth.id,
      employeeName: req.auth.name,
      email: req.auth.email,
      type, reason, startDate, endDate
    });
    res.status(201).json({ message: "Leave request submitted", leave });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.patch("/api/leaves/:id", authenticate, authorize("HR", "Manager"), async (req, res) => {
  try {
    const { status } = req.body;
    if (!["Approved", "Rejected"].includes(status)) {
      return res.status(400).json({ message: "Status must be Approved or Rejected" });
    }
    const leave = await Leave.findByIdAndUpdate(
      req.params.id, { status, reviewedBy: req.auth.id }, { new: true, runValidators: true }
    ).populate("employee", "name email department");
    if (!leave) return res.status(404).json({ message: "Leave request not found" });
    res.json({ message: "Leave status updated", leave });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// -------------------- ATTENDANCE ROUTES --------------------
app.get("/api/attendance", authenticate, async (req, res) => {
  const filter = req.auth.role === "Employee" ? { employee: req.auth.id } : {};
  const records = await Attendance.find(filter).sort({ date: -1 });
  res.json(records);
});

app.post("/api/attendance/check-in", authenticate, authorize("Employee"), async (req, res) => {
  try {
    const date = new Date().toISOString().slice(0, 10);
    const record = await Attendance.create({
      employee: req.auth.id,
      employeeName: req.auth.name,
      email: req.auth.email,
      date,
      status: "Present"
    });
    res.status(201).json({ message: "Attendance marked", record });
  } catch (err) {
    res.status(err.code === 11000 ? 409 : 500).json({
      message: err.code === 11000 ? "Attendance already marked today" : err.message
    });
  }
});

// -------------------- ANNOUNCEMENT ROUTES --------------------
app.get("/api/announcements", authenticate, async (_req, res) => {
  const items = await Announcement.find().populate("author", "name").sort({ createdAt: -1 });
  res.json(items);
});

app.post("/api/announcements", authenticate, authorize("HR"), async (req, res) => {
  try {
    const { title, message } = req.body;
    if (!title || !message) return res.status(400).json({ message: "Title and message are required" });
    const item = await Announcement.create({ title, message, author: req.auth.id });
    res.status(201).json({ message: "Announcement published", item });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// -------------------- TRAINING ROUTES --------------------
app.get("/api/training", authenticate, async (_req, res) => {
  const items = await Training.find().populate("createdBy", "name").sort({ date: 1 });
  res.json(items);
});

app.post("/api/training", authenticate, authorize("HR", "Manager"), async (req, res) => {
  try {
    const { title, description, date, department } = req.body;
    if (!title || !date) return res.status(400).json({ message: "Title and date are required" });
    const item = await Training.create({
      title, description, date, department, createdBy: req.auth.id
    });
    res.status(201).json({ message: "Training program created", item });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// -------------------- DASHBOARD --------------------
app.get("/api/dashboard", authenticate, async (req, res) => {
  const own = req.auth.role === "Employee" ? { employee: req.auth.id } : {};
  const [employees, leaves, pendingLeaves, attendance, announcements, training] = await Promise.all([
    User.countDocuments(),
    Leave.countDocuments(own),
    Leave.countDocuments({ ...own, status: "Pending" }),
    Attendance.countDocuments(own),
    Announcement.countDocuments(),
    Training.countDocuments()
  ]);
  res.json({ employees, leaves, pendingLeaves, attendance, announcements, training });
});

// -------------------- SIMPLE FRONTEND --------------------
const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>StaffSync | HR Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#f3f6fb;font-family:Arial,sans-serif}.sidebar{background:#172554;color:#fff;min-height:100vh;padding:25px 16px}
.brand{color:#38bdf8;font-weight:800;font-size:25px}.nav-btn{color:#e2e8f0;text-align:left;width:100%;margin:4px 0}
.nav-btn:hover,.nav-btn.active{background:#1e40af;color:white}.main{padding:30px}.card{border:0;border-radius:14px;box-shadow:0 5px 18px #0f172a0d}
.stat{font-size:30px;font-weight:700;color:#2563eb}.muted{color:#64748b}
@media(max-width:767px){.sidebar{min-height:auto}.main{padding:18px}}
</style>
</head>
<body>
<div id="app"></div>
<script>
const app=document.getElementById("app");
let token=localStorage.getItem("staffsync_token");
let user=JSON.parse(localStorage.getItem("staffsync_user")||"null");
const request=async(path,method="GET",body)=>{
 const r=await fetch("/api/"+path,{method,headers:{"Content-Type":"application/json",...(token?{Authorization:"Bearer "+token}:{})},...(body?{body:JSON.stringify(body)}:{})});
 const d=await r.json();if(!r.ok)throw new Error(d.message||"Request failed");return d;
};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function loginView(){
 app.innerHTML='<div class="container d-flex align-items-center justify-content-center" style="min-height:100vh"><div class="card p-4" style="width:100%;max-width:420px"><div class="text-center mb-3"><div class="brand">StaffSync</div><div class="muted">Modern Human Resource Management</div></div><div id="notice"></div><form id="login"><label class="form-label">Email</label><input id="email" type="email" class="form-control mb-3" required><label class="form-label">Password</label><input id="password" type="password" class="form-control mb-3" required><button class="btn btn-primary w-100">Sign in</button></form><p class="small muted mt-3 mb-0">Ask your HR administrator for account credentials.</p></div></div>';
 document.getElementById("login").onsubmit=async e=>{e.preventDefault();try{const d=await request("login","POST",{email:email.value,password:password.value});token=d.token;user=d.user;localStorage.setItem("staffsync_token",token);localStorage.setItem("staffsync_user",JSON.stringify(user));dashboard();}catch(err){document.getElementById("notice").innerHTML='<div class="alert alert-danger">'+esc(err.message)+'</div>'; }};
}
function dashboard(){
 const pages=["Dashboard",...(user.role!=="Employee"?["Employees"]:[]),"Attendance","Leave Management","Announcements","Training"];
 app.innerHTML='<div class="container-fluid"><div class="row"><aside class="col-md-2 sidebar"><div class="brand mb-4">StaffSync</div><div class="mb-1">'+esc(user.name)+'</div><span class="badge bg-info text-dark mb-4">'+esc(user.role)+'</span><div id="nav"></div><button id="logout" class="btn btn-danger w-100 mt-3">Logout</button></aside><main class="col-md-10 main"><h2 id="heading">Dashboard</h2><p class="muted">Welcome back, '+esc(user.name)+'</p><div id="notice"></div><div id="content"></div></main></div></div>';
 document.getElementById("nav").innerHTML=pages.map(p=>'<button class="btn nav-btn" data-page="'+esc(p)+'">'+esc(p)+'</button>').join("");
 document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
 document.getElementById("logout").onclick=()=>{localStorage.clear();token=null;user=null;loginView();};
 showPage("Dashboard");
}
const flash=m=>document.getElementById("notice").innerHTML='<div class="alert alert-info">'+esc(m)+'</div>';
async function showPage(page){
 document.getElementById("heading").textContent=page;
 document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 const c=document.getElementById("content");c.innerHTML='<div class="text-muted">Loading...</div>';
 try{
  if(page==="Dashboard"){
   const d=await request("dashboard");
   c.innerHTML='<div class="row g-3">'+Object.entries(d).map(([k,v])=>'<div class="col-6 col-lg-4"><div class="card p-4"><div class="muted">'+esc(k.replace(/([A-Z])/g," $1"))+'</div><div class="stat">'+v+'</div></div></div>').join("")+'</div>';
  }else if(page==="Employees"){
   const d=await request("employees");
   c.innerHTML=(user.role==="HR"?'<div class="card p-4 mb-3"><h5>Add team member</h5><form id="addEmployee" class="row g-2"><div class="col-md-6"><input class="form-control" name="name" placeholder="Full name" required></div><div class="col-md-6"><input class="form-control" name="email" type="email" placeholder="Email" required></div><div class="col-md-6"><input class="form-control" name="password" type="password" minlength="8" placeholder="Temporary password (8+ characters)" required></div><div class="col-md-6"><input class="form-control" name="department" placeholder="Department"></div><div class="col-md-6"><select class="form-select" name="role"><option>Employee</option><option>Manager</option></select></div><div class="col-12"><button class="btn btn-primary">Create account</button></div></form></div>':'')+'<div class="card p-3"><h5>Employee directory</h5><div class="table-responsive"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Role</th></tr></thead><tbody>'+d.map(x=>'<tr><td>'+esc(x.name)+'</td><td>'+esc(x.email)+'</td><td>'+esc(x.department)+'</td><td>'+esc(x.role)+'</td></tr>').join("")+'</tbody></table></div></div>';
   const f=document.getElementById("addEmployee");if(f)f.onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(f));try{await request("employees","POST",b);flash("Employee account created");showPage(page);}catch(err){flash(err.message);}};
  }else if(page==="Leave Management"){
   const d=await request("leaves");
   c.innerHTML=(user.role==="Employee"?'<div class="card p-4 mb-3"><h5>Apply for leave</h5><form id="leaveForm" class="row g-2"><div class="col-md-4"><select name="type" class="form-select" required><option value="">Leave type</option><option>Casual</option><option>Sick</option><option>Earned</option><option>Unpaid</option></select></div><div class="col-md-4"><input name="startDate" type="date" class="form-control" required></div><div class="col-md-4"><input name="endDate" type="date" class="form-control" required></div><div class="col-12"><textarea name="reason" class="form-control" placeholder="Reason" required></textarea></div><div class="col-12"><button class="btn btn-primary">Submit request</button></div></form></div>':'')+'<div class="card p-3"><h5>Leave requests</h5><div class="table-responsive"><table class="table"><thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Reason</th><th>Status</th><th>Action</th></tr></thead><tbody>'+d.map(x=>'<tr><td>'+esc(x.employee?.name||x.employeeName)+'</td><td>'+esc(x.type)+'</td><td>'+new Date(x.startDate).toLocaleDateString()+' – '+new Date(x.endDate).toLocaleDateString()+'</td><td>'+esc(x.reason)+'</td><td>'+esc(x.status)+'</td><td>'+((user.role!=="Employee"&&x.status==="Pending")?'<button class="btn btn-sm btn-success me-1" data-review="'+x._id+'" data-status="Approved">Approve</button><button class="btn btn-sm btn-danger" data-review="'+x._id+'" data-status="Rejected">Reject</button>':'')+'</td></tr>').join("")+'</tbody></table></div></div>';
   const f=document.getElementById("leaveForm");if(f)f.onsubmit=async e=>{e.preventDefault();try{await request("leaves","POST",Object.fromEntries(new FormData(f)));flash("Leave request submitted");showPage(page);}catch(err){flash(err.message);}};
   document.querySelectorAll("[data-review]").forEach(b=>b.onclick=async()=>{try{await request("leaves/"+b.dataset.review,"PATCH",{status:b.dataset.status});flash("Leave "+b.dataset.status.toLowerCase());showPage(page);}catch(err){flash(err.message);}});
  }else if(page==="Attendance"){
   const d=await request("attendance");
   c.innerHTML=(user.role==="Employee"?'<button id="checkin" class="btn btn-primary mb-3">Mark today’s attendance</button>':'')+'<div class="card p-3"><h5>Attendance records</h5><div class="table-responsive"><table class="table"><thead><tr><th>Employee</th><th>Date</th><th>Check-in</th><th>Status</th></tr></thead><tbody>'+d.map(x=>'<tr><td>'+esc(x.employeeName)+'</td><td>'+esc(x.date)+'</td><td>'+new Date(x.checkIn).toLocaleTimeString()+'</td><td>'+esc(x.status)+'</td></tr>').join("")+'</tbody></table></div></div>';
   const b=document.getElementById("checkin");if(b)b.onclick=async()=>{try{await request("attendance/check-in","POST",{});flash("Attendance marked");showPage(page);}catch(err){flash(err.message);}};
  }else if(page==="Announcements"){
   const d=await request("announcements");
   c.innerHTML=(user.role==="HR"?'<div class="card p-4 mb-3"><h5>Publish announcement</h5><form id="announcementForm"><input name="title" class="form-control mb-2" placeholder="Title" required><textarea name="message" class="form-control mb-2" placeholder="Message" required></textarea><button class="btn btn-primary">Publish</button></form></div>':'')+d.map(x=>'<div class="card p-3 mb-3"><h5>'+esc(x.title)+'</h5><p>'+esc(x.message)+'</p><small class="muted">'+new Date(x.createdAt).toLocaleString()+'</small></div>').join("");
   const f=document.getElementById("announcementForm");if(f)f.onsubmit=async e=>{e.preventDefault();try{await request("announcements","POST",Object.fromEntries(new FormData(f)));flash("Announcement published");showPage(page);}catch(err){flash(err.message);}};
  }else if(page==="Training"){
   const d=await request("training");
   c.innerHTML=(user.role!=="Employee"?'<div class="card p-4 mb-3"><h5>Create training program</h5><form id="trainingForm" class="row g-2"><div class="col-md-6"><input name="title" class="form-control" placeholder="Title" required></div><div class="col-md-6"><input name="date" type="date" class="form-control" required></div><div class="col-md-6"><input name="department" class="form-control" placeholder="Department"></div><div class="col-12"><textarea name="description" class="form-control" placeholder="Description"></textarea></div><div class="col-12"><button class="btn btn-primary">Create training</button></div></form></div>':'')+d.map(x=>'<div class="card p-3 mb-3"><h5>'+esc(x.title)+'</h5><p>'+esc(x.description)+'</p><div>Date: '+new Date(x.date).toLocaleDateString()+'</div><div>Department: '+esc(x.department)+'</div></div>').join("");
   const f=document.getElementById("trainingForm");if(f)f.onsubmit=async e=>{e.preventDefault();try{await request("training","POST",Object.fromEntries(new FormData(f)));flash("Training program created");showPage(page);}catch(err){flash(err.message);}};
  }
 }catch(err){c.innerHTML='<div class="alert alert-danger">'+esc(err.message)+'</div>';}
}
if(token&&user)dashboard();else loginView();
</script>
</body>
</html>`;

app.get("/", (_req, res) => res.send(html));
app.get("/api/health", (_req, res) => res.json({ status: "ok", application: "StaffSync" }));

// -------------------- START SERVER --------------------
app.listen(PORT, () => {
  console.log(`StaffSync is running at http://localhost:${PORT}`);
});
