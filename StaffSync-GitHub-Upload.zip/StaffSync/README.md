# StaffSync — Modern Human Resource Management System

StaffSync is a web-based HR management project with three roles: HR, Manager, and Employee.

## Features
- JWT login and role-based access
- HR: create employee/manager accounts, publish announcements
- Employee: apply for leave and mark daily attendance
- HR/Manager: review leave requests and create training programs
- Dashboard statistics
- MongoDB persistence
- Responsive Bootstrap interface served by Express

## Requirements
- Node.js 18+
- MongoDB local service or MongoDB Atlas database

## Run locally
1. Extract this repository.
2. Open the folder in VS Code.
3. Run `npm install`.
4. Set environment variables if needed:
   - `MONGO_URI` (defaults to `mongodb://127.0.0.1:27017/staffsync`)
   - `JWT_SECRET` (set a long random value)
   - `PORT` (defaults to `5000`)
5. Run `npm start`.
6. Open http://localhost:5000.

## Create the first HR account
Use Postman or another API client:

- Method: `POST`
- URL: `http://localhost:5000/api/setup`
- Body type: JSON

```json
{
  "name": "Admin",
  "email": "admin@staffsync.com",
  "password": "Admin@12345"
}
```

Then log in on the home page with those credentials. The setup endpoint is disabled once an account exists.

## GitHub upload
Create a new GitHub repository, then upload the extracted files (`server.js`, `package.json`, `README.md`, `.gitignore`, `.env.example`) or push them with Git.

## Important
This is an academic starter project, not a production-ready HR platform. Before real deployment, configure a strong `JWT_SECRET`, use HTTPS, restrict manager access to assigned teams, add rate limiting and audit logging, and review data privacy/security requirements. Never commit real passwords, database credentials, or `.env` files.
